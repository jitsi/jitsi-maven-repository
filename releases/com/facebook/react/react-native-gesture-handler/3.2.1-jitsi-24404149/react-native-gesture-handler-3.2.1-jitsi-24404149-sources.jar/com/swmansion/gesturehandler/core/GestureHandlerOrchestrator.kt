package com.swmansion.gesturehandler.core

import android.graphics.Matrix
import android.graphics.PointF
import android.util.SparseArray
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import com.facebook.react.uimanager.ReactCompoundView
import com.facebook.react.uimanager.RootView
import com.swmansion.gesturehandler.react.RNGestureHandlerDetectorView
import com.swmansion.gesturehandler.react.RNGestureHandlerRootHelper
import com.swmansion.gesturehandler.react.RNGestureHandlerRootView
import com.swmansion.gesturehandler.react.isHoverAction
import java.util.*

class GestureHandlerOrchestrator(
  private val wrapperView: ViewGroup,
  private val handlerRegistry: GestureHandlerRegistry,
  private val viewConfigHelper: ViewConfigurationHelper,
  private val rootView: ViewGroup,
  private val onJSResponderCancelListener: OnJSResponderCancelListener,
) {
  /**
   * Minimum alpha (value from 0 to 1) that should be set to a view so that it can be treated as a
   * gesture target. E.g. if set to 0.1 then views that less than 10% opaque will be ignored when
   * traversing view hierarchy and looking for gesture handlers.
   */
  var minimumAlphaForTraversal = DEFAULT_MIN_ALPHA_FOR_TRAVERSAL
  private val gestureHandlers = arrayListOf<GestureHandler>()
  private val awaitingHandlers = arrayListOf<GestureHandler>()

  // Pool of reusable lists for snapshotting `gestureHandlers` during event delivery.
  private val handlerListPool = ArrayDeque<ArrayList<GestureHandler>>()

  private fun obtainHandlerList() = handlerListPool.pollLast() ?: ArrayList<GestureHandler>()

  private fun recycleHandlerList(list: ArrayList<GestureHandler>) {
    list.clear()
    handlerListPool.addLast(list)
  }

  // Used by `cancelTouchesInInterceptedViews`.
  private val viewsToCancel = arrayListOf<View>()
  private val pointerDownPoints = SparseArray<PointF>()

  // In `onHandlerStateChange` method we iterate through `awaitingHandlers`, but calling `tryActivate` may modify this list.
  // To avoid `ConcurrentModificationException` we iterate through copy. There is one more problem though - if handler was
  // removed from `awaitingHandlers`, it was still present in copy of original list. This hashset helps us identify which handlers
  // are really inside `awaitingHandlers`.
  // `contains` method on HashSet has O(1) complexity, so calling it inside for loop won't result in O(n^2) (contrary to ArrayList)
  private val awaitingHandlersTags = HashSet<Int>()

  var isHandlingTouch = false
    private set
  private var handlingChangeSemaphore = 0
  private var finishedHandlersCleanupScheduled = false
  private var activationIndex = 0

  /**
   * Should be called from the view wrapper
   */
  fun onTouchEvent(event: MotionEvent): Boolean {
    isHandlingTouch = true
    val action = event.actionMasked
    trackPointerDownPoints(event)
    if (action == MotionEvent.ACTION_DOWN ||
      action == MotionEvent.ACTION_POINTER_DOWN ||
      action == MotionEvent.ACTION_HOVER_MOVE
    ) {
      extractGestureHandlers(event)
    } else if (action == MotionEvent.ACTION_CANCEL) {
      cancelAll()
    }
    deliverEventToGestureHandlers(event)
    isHandlingTouch = false
    if (finishedHandlersCleanupScheduled && handlingChangeSemaphore == 0) {
      cleanupFinishedHandlers()
    }
    if (action == MotionEvent.ACTION_UP ||
      action == MotionEvent.ACTION_CANCEL ||
      action == MotionEvent.ACTION_HOVER_EXIT
    ) {
      if (gestureHandlers.isEmpty() && rootView is RootView) {
        rootView.onChildEndedNativeGesture(rootView, event)
      }
    }
    return true
  }

  fun getHandlersForView(view: View) = handlerRegistry.getHandlersForView(view)

  private fun scheduleFinishedHandlersCleanup() {
    if (isHandlingTouch || handlingChangeSemaphore != 0) {
      finishedHandlersCleanupScheduled = true
    } else {
      cleanupFinishedHandlers()
    }
  }

  private fun cleanupFinishedHandlers() {
    for (handler in gestureHandlers.asReversed()) {
      if (isFinished(handler.state) && !handler.isAwaiting) {
        handler.reset()
        handler.apply {
          isActive = false
          isAwaiting = false
          activationIndex = Int.MAX_VALUE
        }
      }
    }

    gestureHandlers.removeAll { isFinished(it.state) && !it.isAwaiting }

    finishedHandlersCleanupScheduled = false
  }

  private fun hasOtherHandlerToWaitFor(handler: GestureHandler) =
    gestureHandlers.any { !isFinished(it.state) && shouldHandlerWaitForOther(handler, it) }

  private fun shouldBeCancelledByFinishedHandler(handler: GestureHandler) =
    gestureHandlers.any { shouldHandlerWaitForOther(handler, it) && it.state == GestureHandler.STATE_END }

  private fun shouldBeCancelledByActiveHandler(handler: GestureHandler) = gestureHandlers.any {
    handler.hasCommonPointers(it) &&
      it.state == GestureHandler.STATE_ACTIVE &&
      !canRunSimultaneously(handler, it) &&
      handler.isDescendantOf(it)
  }

  private fun tryActivate(handler: GestureHandler) {
    // If we are waiting for a gesture that has successfully finished, we should cancel handler
    if (shouldBeCancelledByFinishedHandler(handler) || shouldBeCancelledByActiveHandler(handler)) {
      handler.cancel()
      return
    }

    // see if there is anyone else who we need to wait for
    if (hasOtherHandlerToWaitFor(handler)) {
      addAwaitingHandler(handler)
    } else {
      // we can activate handler right away
      makeActive(handler)
      handler.isAwaiting = false
    }
  }

  private fun cleanupAwaitingHandlers() {
    val awaitingHandlersCopy = awaitingHandlers.toList()

    for (handler in awaitingHandlersCopy) {
      if (!handler.isAwaiting) {
        awaitingHandlers.remove(handler)
        awaitingHandlersTags.remove(handler.tag)
      }
    }
  }

  /*package*/
  fun onHandlerStateChange(handler: GestureHandler, newState: Int, prevState: Int) {
    handlingChangeSemaphore += 1

    if (handler.isAwaiting &&
      (newState == GestureHandler.STATE_CANCELLED || newState == GestureHandler.STATE_FAILED)
    ) {
      handler.isAwaiting = false
    }

    if (isFinished(newState)) {
      // We have to loop through copy in order to avoid modifying collection
      // while iterating over its elements
      val currentlyAwaitingHandlers = awaitingHandlers.toList()

      // if there were handlers awaiting completion of this handler, we can trigger active state
      for (otherHandler in currentlyAwaitingHandlers) {
        if (!shouldHandlerWaitForOther(otherHandler, handler) ||
          !awaitingHandlersTags.contains(otherHandler.tag)
        ) {
          continue
        }

        if (newState == GestureHandler.STATE_END) {
          // gesture has ended, we need to kill the awaiting handler
          otherHandler.cancel()
          if (otherHandler.state == GestureHandler.STATE_END) {
            // Handle edge case, where discrete gestures end immediately after activation thus
            // their state is set to END and when the gesture they are waiting for activates they
            // should be cancelled, however `cancel` was never sent as gestures were already in the END state.
            // Send synthetic BEGAN -> CANCELLED to properly handle JS logic
            otherHandler.dispatchStateChange(
              GestureHandler.STATE_CANCELLED,
              GestureHandler.STATE_BEGAN,
            )
          }
          otherHandler.isAwaiting = false
        } else {
          // gesture has failed recognition, we may try activating
          tryActivate(otherHandler)
        }
      }
      cleanupAwaitingHandlers()
    }
    if (newState == GestureHandler.STATE_ACTIVE) {
      tryActivate(handler)
    } else if (prevState == GestureHandler.STATE_ACTIVE || prevState == GestureHandler.STATE_END) {
      if (handler.isActive) {
        handler.dispatchStateChange(newState, prevState)
      } else if (newState == GestureHandler.STATE_CANCELLED || newState == GestureHandler.STATE_FAILED
      ) {
        // Handle edge case where handler awaiting for another one tries to activate but finishes
        // before the other would not send state change event upon ending. Note that we only want
        // to do this if the newState is either CANCELLED or FAILED, if it is END we still want to
        // wait for the other handler to finish as in that case synthetic events will be sent by the
        // makeActive method.
        // This also covers the case where a discrete gesture (e.g. Tap) ends immediately after
        // activation (STATE_ACTIVE -> STATE_END) while still awaiting another handler, and is later
        // cancelled when that handler activates.
        handler.dispatchStateChange(newState, GestureHandler.STATE_BEGAN)
      }
    } else if (prevState != GestureHandler.STATE_UNDETERMINED ||
      newState != GestureHandler.STATE_CANCELLED
    ) {
      // If handler is changing state from UNDETERMINED to CANCELLED, the state change event shouldn't
      // be sent. Handler hasn't yet began so it may not be initialized which results in crashes.
      // If it doesn't crash, there may be some weird behavior on JS side, as `onFinalize` will be
      // called without calling `onBegin` first.
      handler.dispatchStateChange(newState, prevState)
    }
    handlingChangeSemaphore -= 1
    scheduleFinishedHandlersCleanup()
  }

  private fun makeActive(handler: GestureHandler) {
    val currentState = handler.state
    with(handler) {
      isAwaiting = false
      isActive = true
      shouldResetProgress = true
      activationIndex = this@GestureHandlerOrchestrator.activationIndex++
    }

    for (otherHandler in gestureHandlers.asReversed()) {
      if (shouldHandlerBeCancelledBy(otherHandler, handler)) {
        otherHandler.cancel()
      }
    }

    // Clear all awaiting handlers waiting for the current handler to fail
    for (otherHandler in awaitingHandlers.asReversed()) {
      if (shouldHandlerBeCancelledBy(otherHandler, handler)) {
        otherHandler.isAwaiting = false
      }
    }
    cleanupAwaitingHandlers()

    // At this point the waiting handler is allowed to activate, so we need to send BEGAN -> ACTIVE event
    // as it wasn't sent before. If handler has finished recognizing the gesture before it was allowed to
    // activate, we also need to send ACTIVE -> END and END -> UNDETERMINED events, as it was blocked from
    // sending events while waiting.
    // There is one catch though - if the handler failed or was cancelled while waiting, relevant event has
    // already been sent. The following chain would result in artificially activating that handler after the
    // failure logic was ran and we don't want to do that.
    if (currentState == GestureHandler.STATE_FAILED ||
      currentState == GestureHandler.STATE_CANCELLED
    ) {
      return
    }

    if (handler.cancelsJSResponder) {
      onJSResponderCancelListener?.onCancelJSResponderRequested(handler)
    }

    handler.dispatchStateChange(GestureHandler.STATE_ACTIVE, GestureHandler.STATE_BEGAN)

    if (currentState != GestureHandler.STATE_ACTIVE) {
      handler.dispatchStateChange(GestureHandler.STATE_END, GestureHandler.STATE_ACTIVE)
      if (currentState != GestureHandler.STATE_END) {
        handler.dispatchStateChange(GestureHandler.STATE_UNDETERMINED, GestureHandler.STATE_END)
      }
    }
  }

  private fun deliverEventToGestureHandlers(event: MotionEvent) {
    // Snapshot handlers into a pooled list, because the list of active handlers can change
    // as a result of state updates (and delivery can be re-entrant).
    val handlersToProcess = obtainHandlerList()
    handlersToProcess.addAll(gestureHandlers)

    // We want to deliver events to active handlers first in order of their activation (handlers
    // that activated first will first get event delivered). Otherwise we deliver events in the
    // order in which handlers has been added ("most direct" children goes first). Therefore we rely
    // on Arrays.sort providing a stable sort (as children are registered in order in which they
    // should be tested)
    handlersToProcess.sortWith(handlersComparator)

    try {
      for (handler in handlersToProcess) {
        deliverEventToGestureHandler(handler, event)
      }
    } finally {
      recycleHandlerList(handlersToProcess)
    }
  }

  private fun cancelAll() {
    // We need `toList` as `awaitingHandlers` can be modified by `cancel`:
    // `onHandlerStateChange` -> `tryActivate` -> `addAwaitingHandler`
    for (handler in awaitingHandlers.asReversed().toList()) {
      handler.cancel()
    }

    // Iterate over a copy, because the list of active handlers can change
    // as a result of state updates
    for (handler in gestureHandlers.reversed()) {
      handler.cancel()
    }
  }

  private fun deliverEventToGestureHandler(handler: GestureHandler, sourceEvent: MotionEvent) {
    if (!isViewAttachedUnderWrapper(handler.view ?: handler.hostDetectorView)) {
      handler.cancel()
      return
    }

    if (!handler.wantsEvent(sourceEvent)) {
      return
    }

    val action = sourceEvent.actionMasked
    val event = transformEventToViewCoords(handler.coordinateView, MotionEvent.obtain(sourceEvent))

    if (handler.needsPointerData) {
      handler.updatePointerData(event, sourceEvent)
    }

    if (!handler.isAwaiting || action != MotionEvent.ACTION_MOVE) {
      handler.handle(event, sourceEvent)
      if (handler.state == GestureHandler.STATE_ACTIVE && handler.isActive) {
        // After handler is done waiting for other one to fail its progress should be
        // reset, otherwise there may be a visible jump in values sent by the handler.
        // When handler is waiting it's already activated but the `isAwaiting` flag
        // prevents it from receiving touch stream. When the flag is changed, the
        // difference between this event and the last one may be large enough to be
        // visible in interactions based on this gesture. This makes it consistent with
        // the behavior on iOS.
        if (handler.shouldResetProgress) {
          handler.shouldResetProgress = false
          handler.resetProgress()
        }
        handler.dispatchHandlerUpdate(event)
      }

      // if event was of type UP or POINTER_UP we request handler to stop tracking now that
      // the event has been dispatched
      if (action == MotionEvent.ACTION_UP ||
        action == MotionEvent.ACTION_POINTER_UP ||
        action == MotionEvent.ACTION_HOVER_EXIT
      ) {
        val pointerId = event.getPointerId(event.actionIndex)
        handler.stopTrackingPointer(pointerId)
      }
    }

    event.recycle()
  }

  /**
   * Cancels all handlers created using API v1 and v2
   */
  fun cancelAllLegacyHandlers() {
    val handlersToProcess = obtainHandlerList()
    handlersToProcess.addAll(gestureHandlers)

    try {
      handlersToProcess.forEach {
        if (it.actionType == GestureHandler.ACTION_TYPE_JS_FUNCTION_OLD_API ||
          it.actionType == GestureHandler.ACTION_TYPE_JS_FUNCTION_NEW_API ||
          it.actionType == GestureHandler.ACTION_TYPE_REANIMATED_WORKLET ||
          it.actionType == GestureHandler.ACTION_TYPE_NATIVE_ANIMATED_EVENT
        ) {
          it.cancel()
        }
      }

      scheduleFinishedHandlersCleanup()
    } finally {
      recycleHandlerList(handlersToProcess)
    }
  }

  /**
   * isViewAttachedUnderWrapper checks whether all of parents for view related to handler
   * view are attached. Since there might be an issue rarely observed when view
   * has been detached and handler's state hasn't been change to canceled, failed or
   * ended yet. Probably it's a result of some race condition and stopping delivering
   * for this handler and changing its state to failed of end appear to be good enough solution.
   */
  private fun isViewAttachedUnderWrapper(view: View?): Boolean {
    if (view == null) {
      return false
    }
    if (view === wrapperView) {
      return true
    }
    var current: View = view
    while (true) {
      val parent = current.parent as? ViewGroup ?: return false

      when {
        // A disappearing child (kept drawable for an exit animation, e.g. RNScreens during a
        // navigation transition) still has `parent` set but is gone from `mChildren`. Treat as
        // detached - `cancelTouchTarget` already synthesized ACTION_CANCEL into this subtree.
        parent.indexOfChild(current) < 0 -> return false
        parent === wrapperView -> return true
        else -> current = parent
      }
    }
  }

  fun isAnyHandlerActive() = gestureHandlers.any { it.state == GestureHandler.STATE_ACTIVE }

  /**
   * Transforms an event in the coordinates of wrapperView into the coordinate space of the received view.
   *
   * This modifies and returns the same event as it receives
   *
   * @param view - view to which coordinate space the event should be transformed
   * @param event - event to transform
   */
  fun transformEventToViewCoords(view: View?, event: MotionEvent): MotionEvent {
    if (view == null) {
      return event
    }

    val parent = view.parent as? ViewGroup
    // Events are passed down to the orchestrator by the wrapperView, so they are already in the
    // relevant coordinate space. We want to stop traversing the tree when we reach it.
    if (parent != wrapperView) {
      transformEventToViewCoords(parent, event)
    }

    if (parent != null) {
      val localX = event.x + parent.scrollX - view.left
      val localY = event.y + parent.scrollY - view.top
      event.setLocation(localX, localY)
    }

    if (!view.matrix.isIdentity) {
      view.matrix.invert(inverseMatrix)
      event.transform(inverseMatrix)
    }

    return event
  }

  /**
   * Transforms a point in the coordinates of wrapperView into the coordinate space of the received view.
   *
   * This modifies and returns the same point as it receives
   *
   * @param view - view to which coordinate space the point should be transformed
   * @param point - point to transform
   */
  fun transformPointToViewCoords(view: View?, point: PointF): PointF {
    if (view == null) {
      return point
    }

    val parent = view.parent as? ViewGroup
    // Events are passed down to the orchestrator by the wrapperView, so they are already in the
    // relevant coordinate space. We want to stop traversing the tree when we reach it.
    if (parent != wrapperView) {
      transformPointToViewCoords(parent, point)
    }

    if (parent != null) {
      point.x += parent.scrollX - view.left
      point.y += parent.scrollY - view.top
    }

    if (!view.matrix.isIdentity) {
      view.matrix.invert(inverseMatrix)
      tempCoords[0] = point.x
      tempCoords[1] = point.y
      inverseMatrix.mapPoints(tempCoords)
      point.x = tempCoords[0]
      point.y = tempCoords[1]
    }

    return point
  }

  private fun addAwaitingHandler(handler: GestureHandler) {
    if (awaitingHandlers.contains(handler)) {
      return
    }

    awaitingHandlers.add(handler)
    awaitingHandlersTags.add(handler.tag)

    with(handler) {
      isAwaiting = true
      activationIndex = this@GestureHandlerOrchestrator.activationIndex++
    }
  }

  fun recordHandlerIfNotPresent(handler: GestureHandler, view: View?) {
    if (gestureHandlers.contains(handler)) {
      return
    }

    handler.isActive = false
    handler.isAwaiting = false
    handler.activationIndex = Int.MAX_VALUE
    handler.prepare(view, this)

    if (!handler.shouldBeginWithRecordedHandlers(gestureHandlers)) {
      handler.cancel()
    }

    gestureHandlers.add(handler)
  }

  private fun isViewOverflowingParent(view: View): Boolean {
    val parent = view.parent as? ViewGroup ?: return false
    val matrix = view.matrix
    val localXY = matrixTransformCoords
    localXY[0] = 0f
    localXY[1] = 0f
    matrix.mapPoints(localXY)
    val left = localXY[0] + view.left
    val top = localXY[1] + view.top

    return left < 0f ||
      left + view.width > parent.width ||
      top < 0f ||
      top + view.height > parent.height
  }

  private fun extractAncestorHandlers(view: View, coords: FloatArray, pointerId: Int, event: MotionEvent): Boolean {
    var found = false
    var parent = view.parent

    while (parent != null) {
      if (parent is ViewGroup) {
        // Stop traversing the hierarchy when encountering another active root view to prevent
        // gestures from being extracted multiple times by different orchestrators.
        if (parent is RNGestureHandlerRootView && parent.isRootViewEnabled()) {
          break
        }

        val parentViewGroup: ViewGroup = parent

        handlerRegistry.getHandlersForView(parent)?.let {
          synchronized(it) {
            for (handler in it) {
              if (shouldHandlerSkipHoverEvents(handler, event)) {
                continue
              }

              if (handler.isEnabled && handler.isWithinBounds(view, coords[0], coords[1])) {
                found = true
                recordHandlerIfNotPresent(handler, parentViewGroup)
                handler.startTrackingPointer(pointerId)
              }
            }
          }
        }
      }

      parent = parent.parent
    }

    return found
  }

  // We don't want to extract gestures other than hover when processing hover events.
  // There's only one exception - RootViewGestureHandler. TalkBack uses hover events,
  // so we need to pass them into RootViewGestureHandler, otherwise press and hold
  // gesture stops working correctly (see https://github.com/software-mansion/react-native-gesture-handler/issues/3407)
  private fun shouldHandlerSkipHoverEvents(handler: GestureHandler, event: MotionEvent): Boolean {
    val shouldSkipHoverEvents =
      handler !is HoverGestureHandler &&
        handler !is RNGestureHandlerRootHelper.RootViewGestureHandler

    return shouldSkipHoverEvents && event.isHoverAction()
  }

  private fun recordViewHandlersForPointer(
    view: View,
    coords: FloatArray,
    pointerId: Int,
    event: MotionEvent,
    useChildBounds: Boolean = false,
  ): Boolean {
    var boundsView = view
    var boundsX = coords[0]
    var boundsY = coords[1]

    // When `useChildBounds` is set, handler bounds are checked in the coordinate space of the view's
    // single child instead of against the view itself. The caller only sets this for a native detector
    // with exactly one child, so its interactive area follows the child's transforms (e.g. `translateX`)
    // rather than the detector's transform-agnostic frame. For an identity transform the child fills the
    // detector, so this matches the detector's own frame and `hitSlop` expansion (#4049) keeps working;
    // for a translated child the area follows the content.
    if (useChildBounds) {
      val child = (view as RNGestureHandlerDetectorView).getChildAt(0)
      val childPoint = tempPoint
      transformPointToChildViewCoords(coords[0], coords[1], view, child, childPoint)
      boundsView = child
      boundsX = childPoint.x
      boundsY = childPoint.y
    }

    var found = false
    handlerRegistry.getHandlersForView(view)?.let {
      synchronized(it) {
        for (handler in it) {
          // skip disabled and out-of-bounds handlers
          if (!handler.isEnabled || !handler.isWithinBounds(boundsView, boundsX, boundsY)) {
            continue
          }

          if (shouldHandlerSkipHoverEvents(handler, event)) {
            continue
          }

          recordHandlerIfNotPresent(handler, view)
          handler.startTrackingPointer(pointerId)
          found = true
        }
      }
    }

    // if the pointer is inside the view but it overflows its parent, handlers attached to the parent
    // might not have been extracted (pointer might be in a child, but may be outside parent)
    if (coords[0] in 0f..view.width.toFloat() &&
      coords[1] in 0f..view.height.toFloat() &&
      isViewOverflowingParent(view) &&
      extractAncestorHandlers(view, coords, pointerId, event)
    ) {
      found = true
    }

    if (view is ReactCompoundView) {
      // Some implementations (e.g. RNScreens' DimmingView) intentionally throw from `reactTagForTouch`
      val tagForCoords =
        try {
          view.reactTagForTouch(coords[0], coords[1])
        } catch (e: IllegalStateException) {
          null
        }

      if (tagForCoords != null && tagForCoords != view.id) {
        handlerRegistry.getHandlersForViewWithTag(tagForCoords)?.let {
          synchronized(it) {
            for (handler in it) {
              if (shouldHandlerSkipHoverEvents(handler, event)) {
                continue
              }

              recordHandlerIfNotPresent(handler, view)
              handler.startTrackingPointer(pointerId)
              found = true
            }
          }
        }
      }
    }

    return found
  }

  private fun extractGestureHandlers(event: MotionEvent) {
    val actionIndex = event.actionIndex
    val pointerId = event.getPointerId(actionIndex)
    tempCoords[0] = event.getX(actionIndex)
    tempCoords[1] = event.getY(actionIndex)
    traverseWithPointerEvents(wrapperView, tempCoords, pointerId, event)
    extractGestureHandlers(wrapperView, tempCoords, pointerId, event)
  }

  private fun shouldIgnoreSubtreeIfGestureHandlerRootView(view: View) =
    view is RNGestureHandlerRootView && view != wrapperView && view.isRootViewEnabled()

  private fun extractGestureHandlers(
    viewGroup: ViewGroup,
    coords: FloatArray,
    pointerId: Int,
    event: MotionEvent,
  ): Boolean {
    if (shouldIgnoreSubtreeIfGestureHandlerRootView(viewGroup)) {
      // When we encounter another active root view while traversing the view hierarchy, we want
      // to stop there so that it can handle the gesture attached under it itself.
      // This helps in cases where a view may call `requestDisallowInterceptTouchEvent` (which would
      // cancel all gestures handled by its parent root view) but there may be some gestures attached
      // to views under it which should work. Adding another root view under that particular view
      // would allow the gesture to be recognized even though the parent root view cancelled its gestures.
      // We want to stop here so the gesture receives event only once.
      return false
    }

    val childrenCount = viewGroup.childCount
    for (i in childrenCount - 1 downTo 0) {
      val child = viewGroup.getChildAt(i)
      if (canReceiveEvents(child)) {
        val childPoint = tempPoint
        transformPointToChildViewCoords(coords[0], coords[1], viewGroup, child, childPoint)
        val restoreX = coords[0]
        val restoreY = coords[1]
        coords[0] = childPoint.x
        coords[1] = childPoint.y
        var found = false
        if (!isClipping(child) || isTransformedTouchPointInView(coords[0], coords[1], child)) {
          // we only consider the view if touch is inside the view bounds or if the view's children
          // can render outside of the view bounds (overflow visible)
          found = traverseWithPointerEvents(child, coords, pointerId, event)
        }
        coords[0] = restoreX
        coords[1] = restoreY
        if (found) {
          return true
        }
      }
    }
    return false
  }

  private fun trackPointerDownPoints(event: MotionEvent) {
    val index = event.actionIndex
    when (event.actionMasked) {
      MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN ->
        pointerDownPoints.put(event.getPointerId(index), PointF(event.getX(index), event.getY(index)))
      MotionEvent.ACTION_POINTER_UP ->
        pointerDownPoints.remove(event.getPointerId(index))
      MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
        pointerDownPoints.clear()
    }
  }

  fun cancelTouchesInInterceptedViews(event: MotionEvent) {
    viewsToCancel.clear()
    for (i in 0 until pointerDownPoints.size()) {
      val point = pointerDownPoints.valueAt(i)
      tempCoords[0] = point.x
      tempCoords[1] = point.y
      collectViewsAtPoint(wrapperView, tempCoords, viewsToCancel)
    }

    if (viewsToCancel.isEmpty()) {
      return
    }

    val activeHandlers = gestureHandlers.filter { it.isActive }
    val cancelEvent = MotionEvent.obtain(event).apply { action = MotionEvent.ACTION_CANCEL }

    for (view in viewsToCancel) {
      if (view === wrapperView || isViewDrivenByActiveNativeGesture(view, activeHandlers)) {
        continue
      }
      view.onTouchEvent(cancelEvent)
    }

    cancelEvent.recycle()
    viewsToCancel.clear()
  }

  // Whether the view's touch is still owned by a NativeViewGestureHandler that survived arbitration.
  // Only those are fed through `onTouchEvent`, so only those break if cancelled. Other handlers are
  // orchestrator-driven and unaffected.
  private fun isViewDrivenByActiveNativeGesture(view: View, activeHandlers: List<GestureHandler>) =
    handlerRegistry.getHandlersForView(view)?.let { handlers ->
      synchronized(handlers) {
        handlers.any { nativeGestureSurvivesArbitration(it, activeHandlers) }
      }
    } ?: false

  // A native handler survives arbitration if it is active, or it does not conflict with any active handler.
  private fun nativeGestureSurvivesArbitration(handler: GestureHandler, activeHandlers: List<GestureHandler>) =
    handler is NativeViewGestureHandler &&
      (handler.isActive || activeHandlers.none { shouldHandlerBeCancelledBy(handler, it) })

  // Collects the view path under the point (topmost child first, like touch dispatch), leaf to root.
  private fun collectViewsAtPoint(view: View, coords: FloatArray, out: MutableList<View>): Boolean {
    if (shouldIgnoreSubtreeIfGestureHandlerRootView(view)) {
      // A nested active root view manages its own subtree (and its own interception cancellation).
      return false
    }

    val pointerEvents = viewConfigHelper.getPointerEventsConfigForView(view)
    if (pointerEvents == PointerEventsConfig.NONE) {
      return false
    }

    var found = false
    if (view is ViewGroup && pointerEvents != PointerEventsConfig.BOX_ONLY) {
      for (i in view.childCount - 1 downTo 0) {
        val child = view.getChildAt(i)
        if (!canReceiveEvents(child)) {
          continue
        }
        val childPoint = tempPoint
        transformPointToChildViewCoords(coords[0], coords[1], view, child, childPoint)
        if (isClipping(child) && !isTransformedTouchPointInView(childPoint.x, childPoint.y, child)) {
          continue
        }
        val restoreX = coords[0]
        val restoreY = coords[1]
        coords[0] = childPoint.x
        coords[1] = childPoint.y
        found = collectViewsAtPoint(child, coords, out)
        coords[0] = restoreX
        coords[1] = restoreY

        if (found) {
          break
        }
      }
    }

    // BOX_NONE views can't be the target themselves, only their children can
    val selfIsTarget = pointerEvents != PointerEventsConfig.BOX_NONE &&
      isTransformedTouchPointInView(coords[0], coords[1], view)

    if (found || selfIsTarget) {
      // `out` may already contain this view when several pointers share part of their path.
      if (!out.contains(view)) {
        out.add(view)
      }
      return true
    }
    return false
  }

  private fun traverseWithPointerEvents(view: View, coords: FloatArray, pointerId: Int, event: MotionEvent): Boolean =
    if (shouldIgnoreSubtreeIfGestureHandlerRootView(view)) {
      // When we encounter another active root view while traversing the view hierarchy, we want
      // to stop there so that it can handle the gesture attached under it itself.
      // This helps in cases where a view may call `requestDisallowInterceptTouchEvent` (which would
      // cancel all gestures handled by its parent root view) but there may be some gestures attached
      // to views under it which should work. Adding another root view under that particular view
      // would allow the gesture to be recognized even though the parent root view cancelled its gestures.
      // We want to stop here so the gesture receives event only once.
      false
    } else {
      when (viewConfigHelper.getPointerEventsConfigForView(view)) {
        PointerEventsConfig.NONE -> {
          // This view and its children can't be the target
          false
        }
        PointerEventsConfig.BOX_ONLY -> {
          // This view is the target, its children don't matter
          (
            recordViewHandlersForPointer(view, coords, pointerId, event) ||
              shouldHandlerlessViewBecomeTouchTarget(view, coords)
            )
        }
        PointerEventsConfig.BOX_NONE -> {
          // This view can't be the target, but its children might
          when (view) {
            is ViewGroup -> {
              extractGestureHandlers(view, coords, pointerId, event).also { found ->
                // A child view is handling touch, also extract handlers attached to this view
                if (found) {
                  recordViewHandlersForPointer(view, coords, pointerId, event)
                } else if (view is RNGestureHandlerDetectorView) {
                  // No child consumed the touch, but we still record the detector's own handlers so
                  // that `hitSlop` expansion keeps working. The detector's frame ignores
                  // child transforms, so for a single-child detector we check bounds in the child's
                  // transform-aware coordinate space - otherwise the detector would steal presses over
                  // areas its content has been moved away from.
                  val useChildBounds = view.childCount == 1
                  recordViewHandlersForPointer(view, coords, pointerId, event, useChildBounds)
                }
              }
            }
            // When <TextInput> has editable set to `false` getPointerEventsConfigForView returns
            // `BOX_NONE` as it's `isEnabled` property is false. In this case we still want to extract
            // handlers attached to the text input, as it makes sense that gestures would work on a
            // non-editable TextInput.
            is EditText -> {
              recordViewHandlersForPointer(view, coords, pointerId, event)
            }
            else -> false
          }
        }
        PointerEventsConfig.AUTO -> {
          // Either this view or one of its children is the target
          val found = if (view is ViewGroup) {
            extractGestureHandlers(view, coords, pointerId, event)
          } else {
            false
          }

          (
            recordViewHandlersForPointer(view, coords, pointerId, event) ||
              found ||
              shouldHandlerlessViewBecomeTouchTarget(view, coords)
            )
        }
      }
    }

  private fun canReceiveEvents(view: View) = view.visibility == View.VISIBLE && view.alpha >= minimumAlphaForTraversal

  // if view is not a view group it is clipping, otherwise we check for `getClipChildren` flag to
  // be turned on and also confirm with the ViewConfigHelper implementation
  private fun isClipping(view: View) = view !is ViewGroup || viewConfigHelper.isViewClippingChildren(view)

  fun activateNativeHandlersForView(view: View) {
    handlerRegistry.getHandlersForView(view)?.forEach {
      if (it !is NativeViewGestureHandler) {
        return@forEach
      }
      this.recordHandlerIfNotPresent(it, view)

      it.withMarkedAsInBounds {
        it.begin()
        it.activate()
        it.end()
      }
    }
  }

  companion object {
    // The limit doesn't necessarily need to exists, it was just simpler to implement it that way
    // it is also more allocation-wise efficient to have a fixed limit

    // Be default fully transparent views can receive touch
    private const val DEFAULT_MIN_ALPHA_FOR_TRAVERSAL = 0f
    private val tempPoint = PointF()
    private val matrixTransformCoords = FloatArray(2)
    private val inverseMatrix = Matrix()
    private val tempCoords = FloatArray(2)
    private val handlersComparator = Comparator<GestureHandler> { a, b ->
      return@Comparator if (a.isActive && b.isActive || a.isAwaiting && b.isAwaiting) {
        // both A and B are either active or awaiting activation, in which case we prefer one that
        // has activated (or turned into "awaiting" state) earlier
        Integer.signum(b.activationIndex - a.activationIndex)
      } else if (a.isActive) {
        -1 // only A is active
      } else if (b.isActive) {
        1 // only B is active
      } else if (a.isAwaiting) {
        -1 // only A is awaiting, B is inactive
      } else if (b.isAwaiting) {
        1 // only B is awaiting, A is inactive
      } else {
        0 // both A and B are inactive, stable order matters
      }
    }

    private fun shouldHandlerlessViewBecomeTouchTarget(view: View, coords: FloatArray): Boolean {
      // The following code is to match the iOS behavior where transparent parts of the views can
      // pass touch events through them allowing sibling nodes to handle them.

      // TODO: this is not an ideal solution as we only consider ViewGroups that has no background set
      // TODO: ideally we should determine the pixel color under the given coordinates and return
      val isLeaf = view !is ViewGroup
      val isNotTransparent = view.getBackground() != null
      val isDirectDetectorChild = view.parent is RNGestureHandlerDetectorView
      val isPointInView = isTransformedTouchPointInView(coords[0], coords[1], view)

      return (isLeaf || isNotTransparent || isDirectDetectorChild) && isPointInView
    }

    fun transformPointToChildViewCoords(x: Float, y: Float, parent: ViewGroup, child: View, outLocalPoint: PointF) {
      var localX = x + parent.scrollX - child.left
      var localY = y + parent.scrollY - child.top
      val matrix = child.matrix
      if (!matrix.isIdentity) {
        val localXY = matrixTransformCoords
        localXY[0] = localX
        localXY[1] = localY
        matrix.invert(inverseMatrix)
        inverseMatrix.mapPoints(localXY)
        localX = localXY[0]
        localY = localXY[1]
      }
      outLocalPoint[localX] = localY
    }

    private fun isTransformedTouchPointInView(x: Float, y: Float, child: View) =
      x in 0f..child.width.toFloat() && y in 0f..child.height.toFloat()

    private fun shouldHandlerWaitForOther(handler: GestureHandler, other: GestureHandler): Boolean =
      handler !== other &&
        (
          handler.shouldWaitForHandlerFailure(other) ||
            other.shouldRequireToWaitForFailure(handler)
          )

    private fun canRunSimultaneously(a: GestureHandler, b: GestureHandler) =
      a === b || a.shouldRecognizeSimultaneously(b) || b.shouldRecognizeSimultaneously(a)

    private fun shouldHandlerBeCancelledBy(handler: GestureHandler, other: GestureHandler): Boolean {
      if (!handler.hasCommonPointers(other)) {
        // if two handlers share no common pointer one can never trigger cancel for the other
        return false
      }
      if (canRunSimultaneously(handler, other)) {
        // if handlers are allowed to run simultaneously, when first activates second can still remain
        // in began state
        return false
      }
      return if (handler !== other &&
        (handler.isAwaiting || handler.state == GestureHandler.STATE_ACTIVE)
      ) {
        // in every other case as long as the handler is about to be activated or already in active
        // state, we delegate the decision to the implementation of GestureHandler#shouldBeCancelledBy
        handler.shouldBeCancelledBy(other)
      } else {
        true
      }
    }

    private fun isFinished(state: Int) = state == GestureHandler.STATE_CANCELLED ||
      state == GestureHandler.STATE_FAILED ||
      state == GestureHandler.STATE_END
  }
}
